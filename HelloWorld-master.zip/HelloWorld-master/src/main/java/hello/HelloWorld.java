package hello;

public class HelloWorld {
    public static String getMessage() {
        return "Hello, World! v0.2.6";
    }
}
